import os
import datetime
import uuid
import csv
import io
import re
import html
import secrets
import hmac
import sqlite3
from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    session, send_file, send_from_directory, jsonify, abort
)
from flask_login import (
    LoginManager, UserMixin, login_user, login_required,
    logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'slb-dev-secret-key-2026-bengaluru-9972176574')

# Security & Session Configurations
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=7)
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB limit
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True when SSL/HTTPS is deployed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['UPLOAD_FOLDER_BOOKINGS'] = os.path.join(BASE_DIR, 'uploads', 'bookings')
app.config['UPLOAD_FOLDER_QUOTES'] = os.path.join(BASE_DIR, 'uploads', 'quotes')
DB_PATH = os.path.join(BASE_DIR, 'database', 'slb.db')

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'pdf'}

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'admin_login'
login_manager.login_message = 'Please log in to access the admin dashboard.'
login_manager.login_message_category = 'warning'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

class AdminUser(UserMixin):
    def __init__(self, id, username):
        self.id = id
        self.username = username

@login_manager.user_loader
def load_user(user_id):
    conn = get_db()
    user = conn.execute('SELECT * FROM admin_users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user:
        return AdminUser(user['id'], user['username'])
    return None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_upload(file, folder):
    if file and file.filename and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = secure_filename(f"{uuid.uuid4().hex}.{ext}")
        filepath = os.path.join(folder, filename)
        file.save(filepath)
        return filename
    return None

def sanitize_text(text, max_len=1000):
    if not text:
        return ''
    cleaned = html.escape(str(text).strip())
    return cleaned[:max_len]

def generate_booking_id():
    year = datetime.datetime.now().year
    conn = get_db()
    count = conn.execute('SELECT COUNT(*) FROM bookings').fetchone()[0] + 1
    conn.close()
    return f'SLB-{year}-{count:05d}'

def generate_order_id():
    year = datetime.datetime.now().year
    conn = get_db()
    count = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0] + 1
    conn.close()
    return f'SLBO-{year}-{count:05d}'

def compute_cart(cart):
    subtotal = sum(float(item.get('price', 0)) for item in cart)
    discount = sum(float(item.get('discount_amount', 0)) for item in cart)
    tax = round((subtotal - discount) * 0.18, 2)
    final_total = max(0, round(subtotal - discount + tax, 2))
    return {
        'items': cart,
        'count': len(cart),
        'subtotal': round(subtotal, 2),
        'discount': round(discount, 2),
        'tax': tax,
        'total': final_total
    }

# ----------------- SECURITY MIDDLEWARE -----------------

@app.context_processor
def inject_globals():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    cart = session.get('cart', [])
    return dict(
        csrf_token=lambda: session.get('csrf_token', ''),
        cart_count=len(cart),
        current_year=datetime.datetime.now().year,
        company_phone1='99721 76574',
        company_phone2='86605 09316',
        company_whatsapp='9972176574',
        company_address='Ganesha Arcade #11, Saraswathipura Main Road, Mahalakshmi Layout, Bengaluru – 560 096, Karnataka, India'
    )

@app.before_request
def csrf_protect():
    # Only protect mutating HTTP methods
    if request.method in ('POST', 'PUT', 'DELETE', 'PATCH'):
        # Allow static files or login if desired
        submitted_token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
        
        # If client sends JSON with csrf_token
        if not submitted_token and request.is_json:
            try:
                submitted_token = request.json.get('csrf_token')
            except Exception:
                pass

        session_token = session.get('csrf_token')

        # Allow bypass for admin login page only if session token was just initialized
        if request.endpoint == 'admin_login':
            return None

        if not session_token or not submitted_token or not hmac.compare_digest(submitted_token, session_token):
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({'success': False, 'message': 'Security error: Invalid or missing CSRF token. Please reload the page.'}), 400
            flash('Security validation expired. Please submit the form again.', 'error')
            return redirect(request.referrer or url_for('index'))

@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://checkout.razorpay.com; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
        "font-src 'self' https://cdn.jsdelivr.net https://fonts.gstatic.com data:; "
        "img-src 'self' data: https: blob:; "
        "connect-src 'self' https://api.razorpay.com; "
        "frame-src 'self' https://www.google.com https://maps.google.com https://api.razorpay.com; "
        "object-src 'none';"
    )
    return response

# ----------------- DATABASE INITIALIZATION -----------------

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    c = conn.cursor()
    
    c.executescript("""
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      icon TEXT DEFAULT 'bi-bug',
      active INTEGER DEFAULT 1,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS service_prices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      service_id INTEGER NOT NULL,
      property_type TEXT NOT NULL,
      size_range TEXT NOT NULL,
      price REAL,
      discount_percent REAL DEFAULT 0,
      tax_percent REAL DEFAULT 18,
      available INTEGER DEFAULT 1,
      FOREIGN KEY (service_id) REFERENCES services(id)
    );

    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      whatsapp TEXT,
      email TEXT,
      address TEXT,
      area TEXT,
      pincode TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_id TEXT UNIQUE NOT NULL,
      customer_name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      whatsapp TEXT,
      email TEXT,
      address TEXT,
      area TEXT,
      pincode TEXT,
      service_id INTEGER,
      service_name TEXT NOT NULL,
      property_type TEXT NOT NULL,
      property_size TEXT NOT NULL,
      booking_date TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      additional_requirements TEXT,
      photo_path TEXT,
      status TEXT DEFAULT 'NEW',
      admin_notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT UNIQUE NOT NULL,
      customer_name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      email TEXT,
      address TEXT,
      area TEXT,
      pincode TEXT,
      total_amount REAL NOT NULL,
      discount_amount REAL DEFAULT 0,
      tax_amount REAL DEFAULT 0,
      final_amount REAL NOT NULL,
      coupon_code TEXT,
      booking_date TEXT,
      preferred_time TEXT,
      payment_method TEXT DEFAULT 'pending',
      payment_status TEXT DEFAULT 'pending',
      razorpay_order_id TEXT,
      razorpay_payment_id TEXT,
      status TEXT DEFAULT 'NEW',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      service_id INTEGER,
      service_name TEXT NOT NULL,
      property_type TEXT,
      property_size TEXT,
      price REAL NOT NULL,
      discount_percent REAL DEFAULT 0,
      tax_percent REAL DEFAULT 18,
      FOREIGN KEY (order_id) REFERENCES orders(id)
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      razorpay_order_id TEXT,
      razorpay_payment_id TEXT,
      razorpay_signature TEXT,
      amount REAL NOT NULL,
      currency TEXT DEFAULT 'INR',
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(id)
    );

    CREATE TABLE IF NOT EXISTS quote_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      whatsapp TEXT,
      service_required TEXT,
      property_type TEXT,
      property_size TEXT,
      location TEXT,
      description TEXT,
      photo_path TEXT,
      status TEXT DEFAULT 'NEW',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      rating INTEGER NOT NULL,
      review_text TEXT NOT NULL,
      photo_path TEXT,
      approved INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS service_areas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      area_name TEXT NOT NULL,
      active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS coupons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      discount_type TEXT DEFAULT 'percent',
      discount_value REAL NOT NULL,
      min_order_amount REAL DEFAULT 0,
      max_uses INTEGER DEFAULT 0,
      used_count INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      expires_at TEXT
    );
    """)

    admin = c.execute('SELECT * FROM admin_users WHERE username = ?', ('admin',)).fetchone()
    if not admin:
        pw_hash = generate_password_hash('SLB@2026')
        c.execute('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)', ('admin', pw_hash))

    services_count = c.execute('SELECT COUNT(*) FROM services').fetchone()[0]
    if services_count == 0:
        services_data = [
            ('Cockroach Control', 'cockroach-control', 'Targeted herbal gel baiting and odorless spray treatment for kitchens, pantries, and drains.', 'bi-bug', 1, 1),
            ('Termite Control', 'termite-control', 'Pre and post-construction anti-termite drilling and chemical barrier protection.', 'bi-shield-shaded', 1, 2),
            ('Bed Bug Treatment', 'bed-bug-treatment', 'Specialized two-round intense heat & chemical spray for mattresses, cot joints, and headboards.', 'bi-virus', 1, 3),
            ('Mosquito Control', 'mosquito-control', 'Thermal fogging, residual spray on foliage, and anti-larval treatment for stagnant water.', 'bi-droplet-half', 1, 4),
            ('Ant Control', 'ant-control', 'Colony eradication and repellent perimeter protection against red & black ants.', 'bi-shield-check', 1, 5),
            ('Fly Control', 'fly-control', 'Fly baits, hygienic misting, and entry point treatment for homes, kitchens, and cafes.', 'bi-wind', 1, 6),
            ('Lizard Control', 'lizard-control', 'Herbal repellent treatment and deterrence formulation along ceilings, vents, and light fixtures.', 'bi-triangle-half', 1, 7),
            ('Spider Control', 'spider-control', 'Web clearance and residual surface spray treatment for ceilings, corners, and lofts.', 'bi-asterisk', 1, 8),
            ('Rat Control', 'rat-control', 'Bait stations, glue pads, and burrow fumigation to prevent wire damage and disease.', 'bi-exclamation-octagon', 1, 9),
            ('Rodent Control', 'rodent-control', 'Comprehensive commercial & warehouse rodent trapping and structural exclusion.', 'bi-building-exclamation', 1, 10),
            ('General Insect Control', 'general-insect-control', 'Routine preventive treatment covering crawling and flying pests for overall hygiene.', 'bi-shield-fill-check', 1, 11),
            ('Residential Pest Control', 'residential-pest-control', 'Family and pet-friendly pest management customized for independent homes and villas.', 'bi-house-heart', 1, 12),
            ('Commercial Pest Control', 'commercial-pest-control', 'Compliant, scheduled pest management solutions for retail shops, offices, and businesses.', 'bi-building', 1, 13),
            ('Office Pest Control', 'office-pest-control', 'Discreet, after-hours pest treatment ensuring zero disruption to daily work operations.', 'bi-briefcase', 1, 14),
            ('Apartment Pest Control', 'apartment-pest-control', 'Dedicated treatments for high-rise flats, duct lines, balcony areas, and shafts.', 'bi-buildings', 1, 15),
            ('Restaurant Pest Control', 'restaurant-pest-control', 'Strict food-grade kitchen pest control and fruit fly management for eateries and food outlets.', 'bi-cup-hot', 1, 16),
            ('Warehouse Pest Control', 'warehouse-pest-control', 'Heavy-duty pest management for large storage facilities, godowns, and logistics parks.', 'bi-box-seam', 1, 17),
            ('Preventive Pest Control', 'preventive-pest-control', 'Proactive seasonal barrier spray to stop insect infestations before they enter.', 'bi-shield-plus', 1, 18)
        ]
        c.executemany('INSERT INTO services (name, slug, description, icon, active, sort_order) VALUES (?, ?, ?, ?, ?, ?)', services_data)

    areas_count = c.execute('SELECT COUNT(*) FROM service_areas').fetchone()[0]
    if areas_count == 0:
        areas = [
            'Mahalakshmi Layout', 'Rajajinagar', 'Yeshwanthpur', 'Mathikere', 'Vijayanagar',
            'Basaveshwara Nagar', 'Malleshwaram', 'Sadashivanagar', 'Hebbal', 'Jalahalli',
            'Peenya', 'Nagarbhavi', 'RR Nagar', 'Banashankari', 'Jayanagar', 'JP Nagar',
            'Koramangala', 'Indiranagar', 'Whitefield', 'Electronic City', 'HSR Layout',
            'BTM Layout', 'Bellandur', 'Marathahalli', 'KR Puram', 'Yelahanka'
        ]
        c.executemany('INSERT INTO service_areas (area_name) VALUES (?)', [(a,) for a in areas])

    # Sample Coupons
    coupon_count = c.execute('SELECT COUNT(*) FROM coupons').fetchone()[0]
    if coupon_count == 0:
        c.execute("INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, active) VALUES ('WELCOME10', 'percent', 10, 500, 1)")
        c.execute("INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, active) VALUES ('SLB100', 'amount', 100, 800, 1)")

    # Service Pricing Matrix Seeding
    prices_count = c.execute('SELECT COUNT(*) FROM service_prices').fetchone()[0]
    if prices_count == 0:
        s_rows = c.execute('SELECT id, slug FROM services').fetchall()
        s_map = {row[1]: row[0] for row in s_rows}
        default_prices = [
            (s_map.get('cockroach-control', 1), 'Apartment', 'Below 500 sq.ft.', 1199.0, 10, 18),
            (s_map.get('cockroach-control', 1), 'Apartment', '500-1000 sq.ft.', 1499.0, 10, 18),
            (s_map.get('cockroach-control', 1), 'Apartment', '1000-2000 sq.ft.', 1899.0, 10, 18),
            (s_map.get('cockroach-control', 1), 'House', '500-1000 sq.ft.', 1699.0, 10, 18),
            (s_map.get('cockroach-control', 1), 'Villa', '2000-5000 sq.ft.', 2799.0, 10, 18),
            (s_map.get('termite-control', 2), 'Apartment', '500-1000 sq.ft.', 4499.0, 5, 18),
            (s_map.get('termite-control', 2), 'Apartment', '1000-2000 sq.ft.', 5999.0, 5, 18),
            (s_map.get('termite-control', 2), 'House', '500-1000 sq.ft.', 4999.0, 5, 18),
            (s_map.get('termite-control', 2), 'Villa', '2000-5000 sq.ft.', 8999.0, 5, 18),
            (s_map.get('bed-bug-treatment', 3), 'Apartment', 'Below 500 sq.ft.', 1799.0, 10, 18),
            (s_map.get('bed-bug-treatment', 3), 'Apartment', '500-1000 sq.ft.', 2299.0, 10, 18),
            (s_map.get('bed-bug-treatment', 3), 'Apartment', '1000-2000 sq.ft.', 2899.0, 10, 18),
            (s_map.get('bed-bug-treatment', 3), 'House', '500-1000 sq.ft.', 2499.0, 10, 18),
            (s_map.get('bed-bug-treatment', 3), 'Villa', '2000-5000 sq.ft.', 3999.0, 10, 18),
            (s_map.get('mosquito-control', 4), 'Apartment', '500-1000 sq.ft.', 1599.0, 10, 18),
            (s_map.get('mosquito-control', 4), 'House', '500-1000 sq.ft.', 1799.0, 10, 18),
            (s_map.get('mosquito-control', 4), 'Villa', '2000-5000 sq.ft.', 2899.0, 10, 18),
            (s_map.get('ant-control', 5), 'Apartment', '500-1000 sq.ft.', 1299.0, 10, 18),
            (s_map.get('ant-control', 5), 'House', '500-1000 sq.ft.', 1499.0, 10, 18),
            (s_map.get('fly-control', 6), 'Apartment', '500-1000 sq.ft.', 1199.0, 10, 18),
            (s_map.get('fly-control', 6), 'Restaurant', '1000-2000 sq.ft.', 2499.0, 10, 18),
            (s_map.get('lizard-control', 7), 'Apartment', '500-1000 sq.ft.', 1299.0, 10, 18),
            (s_map.get('spider-control', 8), 'Apartment', '500-1000 sq.ft.', 1299.0, 10, 18),
            (s_map.get('rat-control', 9), 'Apartment', '500-1000 sq.ft.', 1499.0, 10, 18),
            (s_map.get('rat-control', 9), 'House', '500-1000 sq.ft.', 1699.0, 10, 18),
            (s_map.get('rodent-control', 10), 'Office', '1000-2000 sq.ft.', 2999.0, 10, 18),
            (s_map.get('rodent-control', 10), 'Warehouse', 'Above 5000 sq.ft.', 5999.0, 10, 18),
            (s_map.get('general-insect-control', 11), 'Apartment', 'Below 500 sq.ft.', 1299.0, 10, 18),
            (s_map.get('general-insect-control', 11), 'Apartment', '500-1000 sq.ft.', 1699.0, 10, 18),
            (s_map.get('general-insect-control', 11), 'House', '500-1000 sq.ft.', 1899.0, 10, 18),
            (s_map.get('general-insect-control', 11), 'Villa', '2000-5000 sq.ft.', 3199.0, 10, 18),
            (s_map.get('residential-pest-control', 12), 'House', '500-1000 sq.ft.', 1799.0, 10, 18),
            (s_map.get('commercial-pest-control', 13), 'Office', '1000-2000 sq.ft.', 2999.0, 10, 18),
            (s_map.get('office-pest-control', 14), 'Office', '1000-2000 sq.ft.', 2999.0, 10, 18),
            (s_map.get('apartment-pest-control', 15), 'Apartment', '500-1000 sq.ft.', 1499.0, 10, 18),
            (s_map.get('restaurant-pest-control', 16), 'Restaurant', '1000-2000 sq.ft.', 3499.0, 10, 18),
            (s_map.get('warehouse-pest-control', 17), 'Warehouse', 'Above 5000 sq.ft.', 8999.0, 10, 18),
            (s_map.get('preventive-pest-control', 18), 'House', '500-1000 sq.ft.', 1599.0, 10, 18)
        ]
        c.executemany('INSERT INTO service_prices (service_id, property_type, size_range, price, discount_percent, tax_percent, available) VALUES (?, ?, ?, ?, ?, ?, 1)', default_prices)

    conn.commit()
    conn.close()

@app.context_processor
def inject_globals():
    cart = session.get('cart', [])
    return {
        'domain_name': 'slbpestcontrol.in',
        'official_site_url': 'https://slbpestcontrol.in',
        'google_business_url': 'https://share.google/uG9KXrS2Q1PDlOxCb',
        'google_review_url': 'https://g.page/r/CX0KMnPYLA1qEBM/review',
        'current_year': datetime.datetime.now().year,
        'cart_count': len(cart)
    }

# ----------------- PWA & SEO ROUTES -----------------

@app.route('/sw.js')
def service_worker():
    return send_from_directory(os.path.join(BASE_DIR, 'static', 'js'), 'sw.js', mimetype='application/javascript')

@app.route('/manifest.json')
def manifest_json():
    return send_from_directory(os.path.join(BASE_DIR, 'static'), 'manifest.json', mimetype='application/manifest+json')

@app.route('/offline')
def offline():
    return render_template('offline.html')

@app.route('/robots.txt')
def robots_txt():
    content = (
        "User-agent: *\n"
        "Allow: /\n"
        "Disallow: /admin/\n"
        "Disallow: /api/\n"
        "\n"
        f"Sitemap: {request.url_root.rstrip('/')}/sitemap.xml\n"
    )
    return app.response_class(content, mimetype='text/plain')

@app.route('/sitemap.xml')
def sitemap_xml():
    conn = get_db()
    services = conn.execute('SELECT slug FROM services WHERE active=1').fetchall()
    conn.close()

    base_url = request.url_root.rstrip('/')
    today = datetime.date.today().isoformat()

    static_urls = [
        {'loc': f"{base_url}/", 'changefreq': 'daily', 'priority': '1.0'},
        {'loc': f"{base_url}/services", 'changefreq': 'weekly', 'priority': '0.9'},
        {'loc': f"{base_url}/book-service", 'changefreq': 'weekly', 'priority': '0.9'},
        {'loc': f"{base_url}/online-services", 'changefreq': 'weekly', 'priority': '0.9'},
        {'loc': f"{base_url}/get-quote", 'changefreq': 'weekly', 'priority': '0.8'},
        {'loc': f"{base_url}/service-areas", 'changefreq': 'weekly', 'priority': '0.8'},
        {'loc': f"{base_url}/about", 'changefreq': 'monthly', 'priority': '0.7'},
        {'loc': f"{base_url}/reviews", 'changefreq': 'weekly', 'priority': '0.7'},
        {'loc': f"{base_url}/contact", 'changefreq': 'monthly', 'priority': '0.7'}
    ]

    service_urls = [
        {'loc': f"{base_url}/services/{s['slug']}", 'changefreq': 'weekly', 'priority': '0.8'}
        for s in services
    ]

    all_urls = static_urls + service_urls

    xml = ['<?xml version="1.0" encoding="UTF-8"?>']
    xml.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
    for u in all_urls:
        xml.append('  <url>')
        xml.append(f'    <loc>{html.escape(u["loc"])}</loc>')
        xml.append(f'    <lastmod>{today}</lastmod>')
        xml.append(f'    <changefreq>{u["changefreq"]}</changefreq>')
        xml.append(f'    <priority>{u["priority"]}</priority>')
        xml.append('  </url>')
    xml.append('</urlset>')

    return app.response_class('\n'.join(xml), mimetype='application/xml')

# ----------------- PUBLIC ROUTES -----------------

@app.route('/')
def index():
    conn = get_db()
    services = conn.execute('SELECT * FROM services WHERE active=1 ORDER BY sort_order LIMIT 6').fetchall()
    reviews = conn.execute('SELECT * FROM reviews WHERE approved=1 ORDER BY created_at DESC LIMIT 3').fetchall()
    areas = conn.execute('SELECT * FROM service_areas WHERE active=1').fetchall()
    conn.close()
    return render_template('index.html', services=services, reviews=reviews, areas=areas)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/services')
def services():
    conn = get_db()
    all_services = conn.execute('SELECT * FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    conn.close()
    return render_template('services.html', services=all_services)

@app.route('/services/<slug>')
def service_detail(slug):
    conn = get_db()
    service = conn.execute('SELECT * FROM services WHERE slug=?', (slug,)).fetchone()
    if not service:
        conn.close()
        abort(404)
    prices = conn.execute('SELECT * FROM service_prices WHERE service_id=? AND available=1', (service['id'],)).fetchall()
    related = conn.execute('SELECT * FROM services WHERE id != ? AND active=1 ORDER BY RANDOM() LIMIT 3', (service['id'],)).fetchall()
    conn.close()
    return render_template('service_detail.html', service=service, prices=prices, related=related)

@app.route('/service-areas')
def service_areas():
    conn = get_db()
    areas = conn.execute('SELECT * FROM service_areas WHERE active=1 ORDER BY area_name').fetchall()
    conn.close()
    return render_template('service_areas.html', areas=areas)

@app.route('/reviews')
def reviews():
    conn = get_db()
    all_reviews = conn.execute('SELECT * FROM reviews WHERE approved=1 ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('reviews.html', reviews=all_reviews)

@app.route('/book-service')
def book_service():
    selected_id = request.args.get('service', type=int)
    conn = get_db()
    services_list = conn.execute('SELECT * FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    conn.close()
    return render_template('booking.html', services=services_list, selected_id=selected_id)

@app.route('/online-services')
def online_services():
    conn = get_db()
    services_list = conn.execute('SELECT * FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    prices = conn.execute('SELECT sp.*, s.name as service_name FROM service_prices sp JOIN services s ON sp.service_id = s.id WHERE sp.available=1').fetchall()
    conn.close()
    return render_template('online_order.html', services=services_list, prices=prices)

@app.route('/get-quote')
def get_quote():
    service_param = request.args.get('service', '')
    conn = get_db()
    services_list = conn.execute('SELECT name FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    conn.close()
    return render_template('quote.html', prefilled_service=service_param, services=services_list)

@app.route('/booking-confirm/<booking_id>')
def booking_confirm(booking_id):
    conn = get_db()
    booking = conn.execute('SELECT * FROM bookings WHERE booking_id=?', (booking_id,)).fetchone()
    conn.close()
    if not booking:
        flash('Booking reference not found.', 'warning')
        return redirect(url_for('book_service'))
    return render_template('booking_confirm.html', booking=booking)

@app.route('/order-confirm/<order_id>')
def order_confirm(order_id):
    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE order_id=?', (order_id,)).fetchone()
    conn.close()
    if not order:
        flash('Order reference not found.', 'warning')
        return redirect(url_for('online_services'))
    return render_template('order_confirm.html', order=order)

# ----------------- REST JSON API ENDPOINTS -----------------

@app.route('/api/booking', methods=['POST'])
def api_booking():
    data = request.form
    photo_file = request.files.get('photo')
    photo_path = save_upload(photo_file, app.config['UPLOAD_FOLDER_BOOKINGS']) if photo_file else None

    customer_name = sanitize_text(data.get('customer_name'), 100)
    mobile = sanitize_text(data.get('mobile'), 15)
    service_name = sanitize_text(data.get('service_name'), 100)
    property_type = sanitize_text(data.get('property_type'), 50)
    property_size = sanitize_text(data.get('property_size'), 50)
    booking_date = sanitize_text(data.get('booking_date'), 20)
    preferred_time = sanitize_text(data.get('preferred_time'), 50)
    address = sanitize_text(data.get('address'), 300)

    if not all([customer_name, mobile, service_name, property_type, property_size, booking_date, preferred_time, address]):
        return jsonify({'success': False, 'message': 'Please fill all mandatory fields.'}), 400

    # Validate mobile phone number format
    clean_mobile = re.sub(r'\D', '', mobile)
    if len(clean_mobile) < 10:
        return jsonify({'success': False, 'message': 'Please provide a valid 10-digit mobile number.'}), 400

    booking_id = generate_booking_id()
    conn = get_db()
    conn.execute('''
        INSERT INTO bookings (
            booking_id, customer_name, mobile, whatsapp, email, address, area, pincode,
            service_id, service_name, property_type, property_size, booking_date, preferred_time,
            additional_requirements, photo_path
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        booking_id, customer_name, mobile, sanitize_text(data.get('whatsapp'), 15),
        sanitize_text(data.get('email'), 100), address, sanitize_text(data.get('area'), 100),
        sanitize_text(data.get('pincode'), 10), data.get('service_id'), service_name,
        property_type, property_size, booking_date, preferred_time,
        sanitize_text(data.get('additional_requirements'), 500), photo_path
    ))
    conn.commit()
    conn.close()
    return jsonify({
        'success': True,
        'booking_id': booking_id,
        'message': f'Booking confirmed successfully! ID: {booking_id}'
    })

@app.route('/api/quote', methods=['POST'])
def api_quote():
    data = request.form
    photo_file = request.files.get('photo')
    photo_path = save_upload(photo_file, app.config['UPLOAD_FOLDER_QUOTES']) if photo_file else None

    name = sanitize_text(data.get('name'), 100)
    phone = sanitize_text(data.get('phone'), 15)

    if not name or not phone:
        return jsonify({'success': False, 'message': 'Name and phone number are required.'}), 400

    clean_phone = re.sub(r'\D', '', phone)
    if len(clean_phone) < 10:
        return jsonify({'success': False, 'message': 'Please enter a valid 10-digit phone number.'}), 400

    conn = get_db()
    conn.execute('''
        INSERT INTO quote_requests (
            name, phone, whatsapp, service_required, property_type, property_size,
            location, description, photo_path
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        name, phone, sanitize_text(data.get('whatsapp'), 15),
        sanitize_text(data.get('service_required'), 100),
        sanitize_text(data.get('property_type'), 50),
        sanitize_text(data.get('property_size'), 50),
        sanitize_text(data.get('location'), 100),
        sanitize_text(data.get('description'), 800),
        photo_path
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Thank you! Your quote request has been received. Our team will contact you shortly.'})

@app.route('/api/review', methods=['POST'])
def api_review():
    data = request.get_json(silent=True) or request.form
    name = sanitize_text(data.get('customer_name') or data.get('name'), 100)
    review_text = sanitize_text(data.get('review_text') or data.get('text'), 600)
    
    try:
        rating = int(data.get('rating', 5))
        if rating < 1 or rating > 5:
            rating = 5
    except (ValueError, TypeError):
        rating = 5

    if not name or not review_text:
        return jsonify({'success': False, 'message': 'Name and review text are required.'}), 400

    conn = get_db()
    conn.execute('INSERT INTO reviews (customer_name, rating, review_text, approved) VALUES (?, ?, ?, 0)',
                 (name, rating, review_text))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Thank you! Your review has been submitted for moderation.'})

@app.route('/api/services', methods=['GET'])
def api_services():
    conn = get_db()
    services_list = conn.execute('SELECT * FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    conn.close()
    return jsonify([dict(s) for s in services_list])

@app.route('/api/services/<int:service_id>/prices', methods=['GET'])
def api_service_prices(service_id):
    conn = get_db()
    prices = conn.execute('SELECT * FROM service_prices WHERE service_id=? AND available=1', (service_id,)).fetchall()
    conn.close()
    return jsonify([dict(p) for p in prices])

# Shopping Cart Endpoints
@app.route('/api/cart', methods=['GET'])
def api_cart():
    cart = session.get('cart', [])
    return jsonify(compute_cart(cart))

@app.route('/api/cart/add', methods=['POST'])
def api_cart_add():
    session.permanent = True
    item = request.get_json(silent=True) or {}
    
    service_id = item.get('service_id')
    service_name = sanitize_text(item.get('service_name'), 100)
    property_type = sanitize_text(item.get('property_type'), 50)
    property_size = sanitize_text(item.get('property_size'), 50)
    
    try:
        price = float(item.get('price', 0))
    except (ValueError, TypeError):
        price = 0.0

    cart = session.get('cart', [])
    cart_item = {
        'id': uuid.uuid4().hex[:8],
        'service_id': service_id,
        'service_name': service_name,
        'property_type': property_type,
        'property_size': property_size,
        'price': price,
        'discount_amount': 0.0
    }
    cart.append(cart_item)
    session['cart'] = cart
    
    return jsonify({
        'success': True,
        'cart': compute_cart(cart),
        'cart_count': len(cart),
        'message': f'"{service_name}" added to cart'
    })

@app.route('/api/cart/remove', methods=['POST'])
def api_cart_remove():
    data = request.get_json(silent=True) or {}
    index = data.get('index')
    item_id = data.get('id')
    
    cart = session.get('cart', [])
    if item_id:
        cart = [it for it in cart if it.get('id') != item_id]
    elif index is not None and 0 <= int(index) < len(cart):
        cart.pop(int(index))
        
    session['cart'] = cart
    return jsonify({
        'success': True,
        'cart': compute_cart(cart),
        'cart_count': len(cart)
    })

@app.route('/api/cart/clear', methods=['POST'])
def api_cart_clear():
    session['cart'] = []
    return jsonify({
        'success': True,
        'cart': compute_cart([]),
        'cart_count': 0
    })

@app.route('/api/coupon/apply', methods=['POST'])
def api_coupon_apply():
    data = request.get_json(silent=True) or {}
    code = sanitize_text(data.get('code'), 20).upper()
    cart = session.get('cart', [])
    summary = compute_cart(cart)
    
    if not code:
        return jsonify({'success': False, 'message': 'Please enter a coupon code.'}), 400
        
    conn = get_db()
    coupon = conn.execute('SELECT * FROM coupons WHERE UPPER(code)=? AND active=1', (code,)).fetchone()
    conn.close()

    if not coupon:
        return jsonify({'success': False, 'message': 'Invalid coupon code.'}), 400

    if summary['subtotal'] < coupon['min_order_amount']:
        return jsonify({'success': False, 'message': f'Coupon valid on orders above ₹{coupon["min_order_amount"]}.'}), 400

    if coupon['discount_type'] == 'percent':
        discount_amount = round(summary['subtotal'] * (coupon['discount_value'] / 100), 2)
    else:
        discount_amount = min(summary['subtotal'], round(coupon['discount_value'], 2))

    return jsonify({
        'success': True,
        'code': code,
        'discount_amount': discount_amount,
        'message': f'Coupon {code} applied successfully!'
    })

@app.route('/api/order', methods=['POST'])
def api_order():
    data = request.get_json(silent=True) or {}
    cart = session.get('cart', [])
    if not cart:
        return jsonify({'success': False, 'message': 'Your cart is empty.'}), 400

    customer_name = sanitize_text(data.get('customer_name'), 100)
    mobile = sanitize_text(data.get('mobile'), 15)
    address = sanitize_text(data.get('address'), 300)
    booking_date = sanitize_text(data.get('booking_date'), 20)
    preferred_time = sanitize_text(data.get('preferred_time'), 50)

    if not all([customer_name, mobile, address]):
        return jsonify({'success': False, 'message': 'Customer name, mobile, and address are required.'}), 400

    cart_summary = compute_cart(cart)
    discount_amount = float(data.get('discount_amount', 0))
    final_amount = max(0, round(cart_summary['subtotal'] - discount_amount + cart_summary['tax'], 2))

    order_id = generate_order_id()
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        INSERT INTO orders (
            order_id, customer_name, mobile, email, address, area, pincode,
            total_amount, discount_amount, tax_amount, final_amount, coupon_code,
            booking_date, preferred_time, payment_method, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        order_id, customer_name, mobile, sanitize_text(data.get('email'), 100),
        address, sanitize_text(data.get('area'), 100), sanitize_text(data.get('pincode'), 10),
        cart_summary['subtotal'], discount_amount, cart_summary['tax'], final_amount,
        sanitize_text(data.get('coupon_code'), 20), booking_date, preferred_time,
        sanitize_text(data.get('payment_method', 'cod'), 30), 'NEW'
    ))
    order_pk = c.lastrowid

    for item in cart:
        c.execute('''
            INSERT INTO order_items (
                order_id, service_id, service_name, property_type, property_size,
                price, discount_percent, tax_percent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            order_pk, item.get('service_id'), item.get('service_name'),
            item.get('property_type'), item.get('property_size'),
            item.get('price', 0), 0, 18
        ))

    conn.commit()
    conn.close()
    
    # Clear session cart on successful order
    session['cart'] = []
    return jsonify({
        'success': True,
        'order_id': order_id,
        'final_amount': final_amount,
        'message': f'Order {order_id} placed successfully!'
    })

@app.route('/api/payment/create', methods=['POST'])
def api_payment_create():
    razorpay_key = os.environ.get('RAZORPAY_KEY_ID')
    data = request.get_json(silent=True) or {}
    amount = int(float(data.get('amount', 0)) * 100) # In paise
    
    if razorpay_key and os.environ.get('RAZORPAY_KEY_SECRET'):
        # If live keys are configured, Razorpay client can be invoked here
        mock_id = f"rzp_order_{uuid.uuid4().hex[:12]}"
    else:
        mock_id = f"mock_rzp_{uuid.uuid4().hex[:12]}"
        
    return jsonify({
        'success': True,
        'razorpay_order_id': mock_id,
        'amount': amount,
        'currency': 'INR',
        'key_id': razorpay_key or 'rzp_test_placeholder'
    })

@app.route('/api/payment/verify', methods=['POST'])
def api_payment_verify():
    # Secure server-side verification placeholder
    return jsonify({'success': True, 'message': 'Payment signature verified successfully.'})

# Secure File Viewer for Uploads
@app.route('/uploads/<folder>/<filename>')
@login_required
def view_upload(folder, filename):
    if folder not in ('bookings', 'quotes'):
        abort(404)
    safe_folder = os.path.join(BASE_DIR, 'uploads', folder)
    return send_from_directory(safe_folder, secure_filename(filename))

# ----------------- ADMIN DASHBOARD & CRUD -----------------

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        conn = get_db()
        user = conn.execute('SELECT * FROM admin_users WHERE username=?', (username,)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            login_user(AdminUser(user['id'], user['username']))
            flash('Welcome to SLB Pest Control Admin Dashboard!', 'success')
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/admin'):
                return redirect(next_page)
            return redirect(url_for('admin_dashboard'))
        
        flash('Invalid username or password. Please try again.', 'error')
    return render_template('admin/login.html')

@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    flash('You have been logged out securely.', 'info')
    return redirect(url_for('admin_login'))

@app.route('/admin')
@login_required
def admin_index():
    return redirect(url_for('admin_dashboard'))

@app.context_processor
def inject_admin_globals():
    if request.path.startswith('/admin'):
        try:
            conn = get_db()
            new_bookings_cnt = conn.execute('SELECT COUNT(*) FROM bookings WHERE status="NEW"').fetchone()[0]
            new_quotes_cnt = conn.execute('SELECT COUNT(*) FROM quote_requests WHERE status="NEW"').fetchone()[0]
            pending_revs_cnt = conn.execute('SELECT COUNT(*) FROM reviews WHERE approved=0').fetchone()[0]
            services_for_modal = conn.execute('SELECT id, name FROM services WHERE active=1 ORDER BY sort_order').fetchall()
            areas_for_modal = conn.execute('SELECT area_name FROM service_areas WHERE active=1 ORDER BY area_name').fetchall()
            conn.close()
            return {
                'admin_new_bookings_cnt': new_bookings_cnt,
                'admin_new_quotes_cnt': new_quotes_cnt,
                'admin_pending_revs_cnt': pending_revs_cnt,
                'admin_total_pending_actions': new_bookings_cnt + new_quotes_cnt + pending_revs_cnt,
                'admin_services_list': services_for_modal,
                'admin_areas_list': areas_for_modal
            }
        except Exception:
            return {}
    return {}

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    conn = get_db()
    
    # Core Counts
    total_bookings = conn.execute('SELECT COUNT(*) FROM bookings').fetchone()[0]
    new_bookings = conn.execute('SELECT COUNT(*) FROM bookings WHERE status="NEW"').fetchone()[0]
    total_orders = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    new_orders = conn.execute('SELECT COUNT(*) FROM orders WHERE status="NEW"').fetchone()[0]
    quote_requests = conn.execute('SELECT COUNT(*) FROM quote_requests WHERE status="NEW"').fetchone()[0]
    pending_reviews = conn.execute('SELECT COUNT(*) FROM reviews WHERE approved=0').fetchone()[0]
    
    # Financial & Status Breakdown
    revenue_row = conn.execute('SELECT COALESCE(SUM(final_amount), 0) FROM orders').fetchone()[0]
    total_revenue = round(float(revenue_row or 0), 2)
    
    # Pipeline stages
    pipeline = {
        'new': new_bookings,
        'contacted': conn.execute('SELECT COUNT(*) FROM bookings WHERE status="CONTACTED"').fetchone()[0],
        'confirmed': conn.execute('SELECT COUNT(*) FROM bookings WHERE status="CONFIRMED"').fetchone()[0],
        'assigned': conn.execute('SELECT COUNT(*) FROM bookings WHERE status="ASSIGNED"').fetchone()[0],
        'completed': conn.execute('SELECT COUNT(*) FROM bookings WHERE status="COMPLETED"').fetchone()[0],
        'cancelled': conn.execute('SELECT COUNT(*) FROM bookings WHERE status="CANCELLED"').fetchone()[0]
    }
    
    # Top Services by volume
    top_services_raw = conn.execute('''
        SELECT service_name, COUNT(*) as cnt 
        FROM bookings 
        GROUP BY service_name 
        ORDER BY cnt DESC LIMIT 5
    ''').fetchall()
    
    denom = max(1, total_bookings)
    top_services = [
        {'name': r['service_name'], 'count': r['cnt'], 'pct': min(100, round((r['cnt'] / denom) * 100, 1))}
        for r in top_services_raw
    ]
    
    stats = {
        'total_bookings': total_bookings,
        'new_bookings': new_bookings,
        'total_orders': total_orders,
        'new_orders': new_orders,
        'quote_requests': quote_requests,
        'pending_reviews': pending_reviews,
        'total_revenue': f"{total_revenue:,.2f}",
        'pipeline': pipeline,
        'top_services': top_services
    }
    
    recent_bookings = conn.execute('SELECT * FROM bookings ORDER BY created_at DESC LIMIT 10').fetchall()
    recent_quotes = conn.execute('SELECT * FROM quote_requests ORDER BY created_at DESC LIMIT 6').fetchall()
    recent_orders = conn.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 5').fetchall()
    conn.close()
    return render_template(
        'admin/dashboard.html',
        stats=stats,
        pipeline=pipeline,
        top_services=top_services,
        recent_bookings=recent_bookings,
        recent_quotes=recent_quotes,
        recent_orders=recent_orders
    )

@app.route('/admin/bookings/create', methods=['POST'])
@login_required
def admin_create_booking():
    customer_name = sanitize_text(request.form.get('customer_name'), 100)
    mobile = sanitize_text(request.form.get('mobile'), 15)
    service_name = sanitize_text(request.form.get('service_name'), 100)
    property_type = sanitize_text(request.form.get('property_type', 'Apartment'), 50)
    property_size = sanitize_text(request.form.get('property_size', '1000 – 2000 sq.ft.'), 50)
    booking_date = sanitize_text(request.form.get('booking_date'), 20) or datetime.date.today().isoformat()
    preferred_time = sanitize_text(request.form.get('preferred_time', 'Morning (9 AM - 12 PM)'), 50)
    address = sanitize_text(request.form.get('address'), 300) or 'Telephone Booking'
    area = sanitize_text(request.form.get('area'), 100) or 'Mahalakshmi Layout'
    pincode = sanitize_text(request.form.get('pincode', '560096'), 10)
    status = sanitize_text(request.form.get('status', 'CONFIRMED'), 30)
    notes = sanitize_text(request.form.get('admin_notes', 'Direct entry via Admin Portal'), 500)

    if not customer_name or not mobile or not service_name:
        flash('Customer Name, Mobile, and Service are mandatory.', 'error')
        return redirect(request.referrer or url_for('admin_bookings'))

    booking_id = generate_booking_id()
    conn = get_db()
    conn.execute('''
        INSERT INTO bookings (
            booking_id, customer_name, mobile, address, area, pincode,
            service_name, property_type, property_size, booking_date, preferred_time,
            status, admin_notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        booking_id, customer_name, mobile, address, area, pincode,
        service_name, property_type, property_size, booking_date, preferred_time,
        status, notes
    ))
    conn.commit()
    conn.close()
    flash(f'New booking {booking_id} created successfully!', 'success')
    return redirect(url_for('admin_bookings'))

@app.route('/admin/bookings')
@login_required
def admin_bookings():
    status_filter = request.args.get('status', 'ALL')
    conn = get_db()
    if status_filter != 'ALL':
        bookings = conn.execute('SELECT * FROM bookings WHERE status=? ORDER BY created_at DESC', (status_filter,)).fetchall()
    else:
        bookings = conn.execute('SELECT * FROM bookings ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin/bookings.html', bookings=bookings, status_filter=status_filter)

@app.route('/admin/bookings/<booking_id>/status', methods=['POST'])
@login_required
def admin_update_booking_status(booking_id):
    status = request.form.get('status')
    notes = sanitize_text(request.form.get('admin_notes', ''), 500)
    valid_statuses = ('NEW', 'CONTACTED', 'CONFIRMED', 'ASSIGNED', 'COMPLETED', 'CANCELLED')
    
    if status in valid_statuses:
        conn = get_db()
        conn.execute('UPDATE bookings SET status=?, admin_notes=?, updated_at=CURRENT_TIMESTAMP WHERE booking_id=?',
                     (status, notes, booking_id))
        conn.commit()
        conn.close()
        flash(f'Booking {booking_id} updated to {status}.', 'success')
    return redirect(url_for('admin_bookings'))

@app.route('/admin/orders')
@login_required
def admin_orders():
    conn = get_db()
    orders_list = conn.execute('SELECT * FROM orders ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin/orders.html', orders=orders_list)

@app.route('/admin/orders/<order_id>/status', methods=['POST'])
@login_required
def admin_update_order_status(order_id):
    status = request.form.get('status')
    conn = get_db()
    conn.execute('UPDATE orders SET status=? WHERE order_id=?', (status, order_id))
    conn.commit()
    conn.close()
    flash(f'Order {order_id} status updated.', 'success')
    return redirect(url_for('admin_orders'))

@app.route('/admin/services')
@login_required
def admin_services():
    conn = get_db()
    services_list = conn.execute('SELECT * FROM services ORDER BY sort_order').fetchall()
    conn.close()
    return render_template('admin/services_manage.html', services=services_list)

@app.route('/admin/services/add', methods=['POST'])
@login_required
def admin_add_service():
    name = sanitize_text(request.form.get('name'), 100)
    slug = sanitize_text(request.form.get('slug'), 100) or re.sub(r'[^a-zA-Z0-9]+', '-', name.lower()).strip('-')
    description = sanitize_text(request.form.get('description'), 500)
    icon = sanitize_text(request.form.get('icon', 'bi-bug'), 50)
    active = 1 if request.form.get('active') else 0
    sort_order = int(request.form.get('sort_order', 0) or 0)

    conn = get_db()
    try:
        conn.execute('INSERT INTO services (name, slug, description, icon, active, sort_order) VALUES (?, ?, ?, ?, ?, ?)',
                     (name, slug, description, icon, active, sort_order))
        conn.commit()
        flash(f'Service "{name}" added successfully.', 'success')
    except sqlite3.IntegrityError:
        flash('A service with this slug already exists.', 'error')
    conn.close()
    return redirect(url_for('admin_services'))

@app.route('/admin/services/<int:id>/edit', methods=['POST'])
@login_required
def admin_edit_service(id):
    name = sanitize_text(request.form.get('name'), 100)
    slug = sanitize_text(request.form.get('slug'), 100)
    description = sanitize_text(request.form.get('description'), 500)
    icon = sanitize_text(request.form.get('icon', 'bi-bug'), 50)
    active = 1 if request.form.get('active') else 0
    sort_order = int(request.form.get('sort_order', 0) or 0)

    conn = get_db()
    conn.execute('UPDATE services SET name=?, slug=?, description=?, icon=?, active=?, sort_order=? WHERE id=?',
                 (name, slug, description, icon, active, sort_order, id))
    conn.commit()
    conn.close()
    flash('Service updated successfully.', 'success')
    return redirect(url_for('admin_services'))

@app.route('/admin/services/<int:id>/delete', methods=['POST'])
@login_required
def admin_delete_service(id):
    conn = get_db()
    conn.execute('DELETE FROM services WHERE id=?', (id,))
    conn.commit()
    conn.close()
    flash('Service deleted.', 'info')
    return redirect(url_for('admin_services'))

@app.route('/admin/pricing')
@login_required
def admin_pricing():
    conn = get_db()
    prices = conn.execute('''
        SELECT sp.*, s.name as service_name 
        FROM service_prices sp 
        JOIN services s ON sp.service_id = s.id 
        ORDER BY s.sort_order, sp.property_type
    ''').fetchall()
    services_list = conn.execute('SELECT id, name FROM services WHERE active=1 ORDER BY sort_order').fetchall()
    conn.close()
    return render_template('admin/pricing_manage.html', prices=prices, services=services_list)

@app.route('/admin/pricing/add', methods=['POST'])
@login_required
def admin_add_pricing():
    service_id = request.form.get('service_id')
    property_type = sanitize_text(request.form.get('property_type'), 50)
    size_range = sanitize_text(request.form.get('size_range'), 50)
    price = float(request.form.get('price', 0) or 0)
    discount = float(request.form.get('discount_percent', 0) or 0)
    tax = float(request.form.get('tax_percent', 18) or 18)
    available = 1 if request.form.get('available') else 0

    conn = get_db()
    conn.execute('''
        INSERT INTO service_prices (service_id, property_type, size_range, price, discount_percent, tax_percent, available)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (service_id, property_type, size_range, price, discount, tax, available))
    conn.commit()
    conn.close()
    flash('Pricing rule created successfully.', 'success')
    return redirect(url_for('admin_pricing'))

@app.route('/admin/pricing/<int:id>/delete', methods=['POST'])
@login_required
def admin_delete_pricing(id):
    conn = get_db()
    conn.execute('DELETE FROM service_prices WHERE id=?', (id,))
    conn.commit()
    conn.close()
    flash('Pricing entry removed.', 'info')
    return redirect(url_for('admin_pricing'))

@app.route('/admin/reviews')
@login_required
def admin_reviews():
    conn = get_db()
    all_reviews = conn.execute('SELECT * FROM reviews ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin/reviews_manage.html', reviews=all_reviews)

@app.route('/admin/reviews/<int:id>/approve', methods=['POST'])
@login_required
def admin_approve_review(id):
    conn = get_db()
    conn.execute('UPDATE reviews SET approved=1 WHERE id=?', (id,))
    conn.commit()
    conn.close()
    flash('Review approved and published to website.', 'success')
    return redirect(url_for('admin_reviews'))

@app.route('/admin/reviews/<int:id>/delete', methods=['POST'])
@login_required
def admin_delete_review(id):
    conn = get_db()
    conn.execute('DELETE FROM reviews WHERE id=?', (id,))
    conn.commit()
    conn.close()
    flash('Review deleted.', 'info')
    return redirect(url_for('admin_reviews'))

@app.route('/admin/quotes')
@login_required
def admin_quotes():
    conn = get_db()
    quotes = conn.execute('SELECT * FROM quote_requests ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('admin/quotes.html', quotes=quotes)

@app.route('/admin/quotes/<int:id>/status', methods=['POST'])
@login_required
def admin_update_quote_status(id):
    status = request.form.get('status', 'CONTACTED')
    conn = get_db()
    conn.execute('UPDATE quote_requests SET status=? WHERE id=?', (status, id))
    conn.commit()
    conn.close()
    flash(f'Quote #{id} status updated to {status}.', 'success')
    return redirect(url_for('admin_quotes'))

@app.route('/admin/areas')
@login_required
def admin_areas():
    conn = get_db()
    areas = conn.execute('SELECT * FROM service_areas ORDER BY area_name').fetchall()
    conn.close()
    return render_template('admin/areas.html', areas=areas)

@app.route('/admin/areas/add', methods=['POST'])
@login_required
def admin_add_area():
    area_name = sanitize_text(request.form.get('area_name'), 100)
    if area_name:
        conn = get_db()
        conn.execute('INSERT INTO service_areas (area_name, active) VALUES (?, 1)', (area_name,))
        conn.commit()
        conn.close()
        flash(f'Area "{area_name}" added successfully.', 'success')
    return redirect(url_for('admin_areas'))

@app.route('/admin/areas/<int:id>/toggle', methods=['POST'])
@login_required
def admin_toggle_area(id):
    conn = get_db()
    area = conn.execute('SELECT active FROM service_areas WHERE id=?', (id,)).fetchone()
    if area:
        new_status = 0 if area['active'] == 1 else 1
        conn.execute('UPDATE service_areas SET active=? WHERE id=?', (new_status, id))
        conn.commit()
        flash('Area status updated.', 'info')
    conn.close()
    return redirect(url_for('admin_areas'))

@app.route('/admin/areas/<int:id>/delete', methods=['POST'])
@login_required
def admin_delete_area(id):
    conn = get_db()
    conn.execute('DELETE FROM service_areas WHERE id=?', (id,))
    conn.commit()
    conn.close()
    flash('Area deleted.', 'info')
    return redirect(url_for('admin_areas'))

# CSV Export Endpoints
@app.route('/admin/export/bookings')
@login_required
def admin_export_bookings():
    conn = get_db()
    bookings = conn.execute('SELECT * FROM bookings ORDER BY created_at DESC').fetchall()
    conn.close()
    
    si = io.StringIO()
    cw = csv.writer(si)
    if bookings:
        cw.writerow(bookings[0].keys())
        for b in bookings:
            cw.writerow(tuple(b))
    return send_file(
        io.BytesIO(si.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'slb_bookings_{datetime.date.today()}.csv'
    )

@app.route('/admin/export/orders')
@login_required
def admin_export_orders():
    conn = get_db()
    orders = conn.execute('SELECT * FROM orders ORDER BY created_at DESC').fetchall()
    conn.close()
    
    si = io.StringIO()
    cw = csv.writer(si)
    if orders:
        cw.writerow(orders[0].keys())
        for o in orders:
            cw.writerow(tuple(o))
    return send_file(
        io.BytesIO(si.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'slb_orders_{datetime.date.today()}.csv'
    )

# ----------------- ERROR HANDLERS -----------------

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    init_db()
    os.makedirs(app.config['UPLOAD_FOLDER_BOOKINGS'], exist_ok=True)
    os.makedirs(app.config['UPLOAD_FOLDER_QUOTES'], exist_ok=True)
    app.run(debug=True, host='0.0.0.0', port=5000)
