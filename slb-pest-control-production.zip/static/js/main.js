// ==========================================================================
// SLB PEST CONTROL — MAIN CLIENT ENGINE
// Handles Mobile Navigation, CSRF Headers, Toasts, and UX Enhancements
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  initCSRF();
  initMobileNavigation();
  initScrollEffects();
  initScrollTop();
  initServiceSearch();
  initServiceFilters();
  initLocalitySelector();
  initSectorTabs();
  initAccordions();
});

/**
 * 1. Global CSRF Token Integration
 * Ensures all AJAX fetch calls include the CSRF token header
 */
function getCSRFToken() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.getAttribute('content') : '';
}

function initCSRF() {
  const originalFetch = window.fetch;
  window.fetch = function(url, options = {}) {
    options.headers = options.headers || {};
    const method = (options.method || 'GET').toUpperCase();
    
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
      const token = getCSRFToken();
      if (token) {
        if (options.headers instanceof Headers) {
          options.headers.set('X-CSRF-Token', token);
        } else {
          options.headers['X-CSRF-Token'] = token;
        }
      }
    }
    return originalFetch(url, options);
  };
}

/**
 * 2. Mobile Navigation Drawer
 */
function initMobileNavigation() {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const drawerCloseBtn = document.getElementById('drawerCloseBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const overlay = document.getElementById('mobileDrawerOverlay');

  function openDrawer() {
    if (mobileDrawer && overlay) {
      mobileDrawer.classList.add('active');
      overlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeDrawer() {
    if (mobileDrawer && overlay) {
      mobileDrawer.classList.remove('active');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (hamburgerBtn) hamburgerBtn.addEventListener('click', openDrawer);
  if (drawerCloseBtn) drawerCloseBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);

  // Close when clicking internal drawer links
  document.querySelectorAll('.drawer-link').forEach(link => {
    link.addEventListener('click', closeDrawer);
  });
}

/**
 * 3. Navbar scroll effect
 */
function initScrollEffects() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.08)';
    } else {
      navbar.style.boxShadow = 'none';
    }
  });
}

/**
 * 4. Scroll To Top
 */
function initScrollTop() {
  const btn = document.getElementById('scrollTopBtn');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 350) {
      btn.classList.add('visible');
    } else {
      btn.classList.remove('visible');
    }
  });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * 5. Toast Notification System
 */
function showToast(message, type = 'success') {
  const stack = document.getElementById('toastStack');
  if (!stack) return;

  const toast = document.createElement('div');
  toast.className = `toast-msg toast-${type}`;
  
  const icon = type === 'success' ? 'bi-check-circle-fill' : (type === 'error' ? 'bi-exclamation-octagon-fill' : 'bi-info-circle-fill');
  toast.innerHTML = `<i class="bi ${icon}"></i> <span>${escapeHTML(message)}</span>`;

  stack.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(50px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function escapeHTML(str) {
  const p = document.createElement('p');
  p.textContent = str;
  return p.innerHTML;
}

/**
 * 6. Service Search Filter
 */
function initServiceSearch() {
  const searchInput = document.getElementById('serviceSearchInput');
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase().trim();
    const cards = document.querySelectorAll('.service-card');

    cards.forEach(card => {
      const name = (card.getAttribute('data-name') || '').toLowerCase();
      const desc = (card.querySelector('.service-desc')?.textContent || '').toLowerCase();
      
      if (name.includes(term) || desc.includes(term)) {
        card.style.display = 'flex';
      } else {
        card.style.display = 'none';
      }
    });
  });
}

/**
 * 7. Category Filter Buttons
 */
function initServiceFilters() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter') || 'all';
      const cards = document.querySelectorAll('.service-card');

      cards.forEach(card => {
        if (filter === 'all') {
          card.style.display = 'flex';
        } else {
          const category = card.getAttribute('data-category') || '';
          if (category.includes(filter)) {
            card.style.display = 'flex';
          } else {
            card.style.display = 'none';
          }
        }
      });
    });
  });
}

// Global WhatsApp Helper
function openSLBWhatsApp(customMessage) {
  const text = customMessage || 'Hello SLB Pest Control, I would like to book a pest control service. Please share the available services and pricing.';
  const url = `https://wa.me/919972176574?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

/**
 * 8. Bangalore Locality Quick-Selector (iPest-style)
 */
function initLocalitySelector() {
  const selector = document.getElementById('localitySelector');
  const resultCard = document.getElementById('localityResultCard');
  const localityNameDisplay = document.getElementById('localityNameDisplay');
  const localityBookBtn = document.getElementById('localityBookBtn');
  const localityWhatsAppBtn = document.getElementById('localityWhatsAppBtn');

  if (!selector) return;

  selector.addEventListener('change', (e) => {
    const area = e.target.value;
    if (area && area !== '') {
      if (localityNameDisplay) localityNameDisplay.textContent = area;
      if (localityBookBtn) {
        localityBookBtn.href = `/book-service?area=${encodeURIComponent(area)}`;
      }
      if (localityWhatsAppBtn) {
        const msg = `Hello SLB Pest Control, I need doorstep pest control service in ${area}, Bengaluru. Please share available time slots.`;
        localityWhatsAppBtn.href = `https://wa.me/919972176574?text=${encodeURIComponent(msg)}`;
      }
      if (resultCard) {
        resultCard.style.display = 'flex';
      }
    } else {
      if (resultCard) {
        resultCard.style.display = 'none';
      }
    }
  });
}

/**
 * 9. Residential vs Commercial Sector Switcher
 */
function initSectorTabs() {
  const tabBtns = document.querySelectorAll('.sector-tab-btn');
  if (!tabBtns.length) return;

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const targetId = btn.getAttribute('data-tab');
      document.querySelectorAll('.sector-tab-pane').forEach(pane => {
        pane.classList.remove('active');
      });

      const activePane = document.getElementById(targetId);
      if (activePane) activePane.classList.add('active');
    });
  });
}

/**
 * 10. Service Accordion Toggle (FAQs & Guidelines)
 */
function initAccordions() {
  const headers = document.querySelectorAll('.accordion-header-btn');
  headers.forEach(btn => {
    btn.addEventListener('click', () => {
      const itemBox = btn.closest('.accordion-item-box');
      if (!itemBox) return;

      const isOpen = itemBox.classList.contains('open');
      
      // Close sibling items
      const parent = itemBox.parentElement;
      if (parent) {
        parent.querySelectorAll('.accordion-item-box').forEach(box => {
          box.classList.remove('open');
        });
      }

      // Toggle current
      if (!isOpen) {
        itemBox.classList.add('open');
      }
    });
  });
}

