// ==========================================================================
// SLB PEST CONTROL — CART & ONLINE ORDER SYSTEM
// Synchronized with templates/online_order.html & app.py
// ==========================================================================

let currentSelectedService = null;
let currentBasePrice = 899;
let appliedDiscount = 0;
let appliedCouponCode = '';

document.addEventListener('DOMContentLoaded', () => {
  fetchStoreCart();
  setupDateDefault();
  setupPaymentRadios();
});

function setupDateDefault() {
  const dateInput = document.getElementById('orderBookingDate');
  if (dateInput) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const defaultDate = tomorrow.toISOString().split('T')[0];
    dateInput.min = defaultDate;
    dateInput.value = defaultDate;
  }
}

function setupPaymentRadios() {
  document.querySelectorAll('input[name="orderPaymentMethod"]').forEach(radio => {
    radio.closest('.select-tile')?.addEventListener('click', function() {
      document.querySelectorAll('input[name="orderPaymentMethod"]').forEach(r => {
        r.closest('.select-tile')?.classList.remove('selected');
      });
      radio.checked = true;
      this.classList.add('selected');
    });
  });
}

function handleStoreServiceChange(serviceId) {
  const configBox = document.getElementById('serviceConfigBox');
  if (!serviceId) {
    if (configBox) configBox.style.display = 'none';
    currentSelectedService = null;
    return;
  }

  const select = document.getElementById('orderServiceSelect');
  const selectedOption = select.options[select.selectedIndex];
  
  currentSelectedService = {
    id: serviceId,
    name: selectedOption.getAttribute('data-name') || selectedOption.text
  };

  if (configBox) configBox.style.display = 'block';
  calculateStorePrice();
}

function calculateStorePrice() {
  const type = document.getElementById('orderPropType')?.value || 'House';
  const size = document.getElementById('orderPropSize')?.value || '500-1000 sq.ft.';

  // Base pricing logic (customizable via admin)
  let base = 899;
  if (currentSelectedService?.name?.toLowerCase().includes('termite')) {
    base = 1899;
  } else if (currentSelectedService?.name?.toLowerCase().includes('bed bug')) {
    base = 1499;
  } else if (currentSelectedService?.name?.toLowerCase().includes('commercial') || currentSelectedService?.name?.toLowerCase().includes('warehouse')) {
    base = 2499;
  }

  // Size multipliers
  if (size.includes('Below 500')) base = Math.round(base * 0.8);
  else if (size.includes('1000-2000')) base = Math.round(base * 1.5);
  else if (size.includes('2000-5000')) base = Math.round(base * 2.2);
  else if (size.includes('Above 5000')) base = Math.round(base * 3.5);

  currentBasePrice = base;
  const priceDisplay = document.getElementById('storeEstimatedPrice');
  if (priceDisplay) {
    priceDisplay.textContent = `₹${base.toLocaleString('en-IN')}`;
  }
}

async function addStoreItemToCart() {
  if (!currentSelectedService) {
    showToast('Please select a service first.', 'error');
    return;
  }

  const propType = document.getElementById('orderPropType')?.value || 'House';
  const propSize = document.getElementById('orderPropSize')?.value || '500-1000 sq.ft.';

  try {
    const res = await fetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: currentSelectedService.id,
        service_name: currentSelectedService.name,
        property_type: propType,
        property_size: propSize,
        price: currentBasePrice
      })
    });

    const data = await res.json();
    if (data.success) {
      showToast(data.message || 'Service added to cart!', 'success');
      renderCartUI(data.cart);
    } else {
      showToast(data.message || 'Failed to add item.', 'error');
    }
  } catch (err) {
    console.error('Cart add error:', err);
    showToast('Could not update cart.', 'error');
  }
}

async function fetchStoreCart() {
  try {
    const res = await fetch('/api/cart');
    const data = await res.json();
    renderCartUI(data);
  } catch (err) {
    console.error('Failed to load cart:', err);
  }
}

async function removeStoreCartItem(itemId) {
  try {
    const res = await fetch('/api/cart/remove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: itemId })
    });
    const data = await res.json();
    if (data.success) {
      showToast('Item removed from cart.', 'info');
      renderCartUI(data.cart);
    }
  } catch (err) {
    console.error('Error removing item:', err);
  }
}

function renderCartUI(cartData) {
  const listEl = document.getElementById('cartItemsList');
  const badgeEl = document.getElementById('cartItemBadge');
  const navBadgeEl = document.getElementById('navCartCount');
  const btnCheckout = document.getElementById('btnToggleCheckout');

  const subtotalEl = document.getElementById('cartSubtotalDisplay');
  const taxEl = document.getElementById('cartTaxDisplay');
  const totalEl = document.getElementById('cartFinalTotalDisplay');

  if (!cartData || !cartData.items || cartData.items.length === 0) {
    if (listEl) {
      listEl.innerHTML = `
        <div class="text-center py-4 text-muted">
          <i class="bi bi-bag-x" style="font-size: 2.5rem; color: #CBD5E1;"></i>
          <p class="mt-2" style="font-size: 0.9rem;">Your cart is empty.<br>Choose a service on the left to add.</p>
        </div>
      `;
    }
    if (badgeEl) badgeEl.textContent = '0 items';
    if (navBadgeEl) navBadgeEl.textContent = '0';
    if (btnCheckout) btnCheckout.disabled = true;

    if (subtotalEl) subtotalEl.textContent = '₹0';
    if (taxEl) taxEl.textContent = '₹0';
    if (totalEl) totalEl.textContent = '₹0';
    return;
  }

  // Render items
  if (badgeEl) badgeEl.textContent = `${cartData.count} items`;
  if (navBadgeEl) navBadgeEl.textContent = `${cartData.count}`;
  if (btnCheckout) btnCheckout.disabled = false;

  let itemsHtml = '';
  cartData.items.forEach(item => {
    itemsHtml += `
      <div class="cart-line-item">
        <div class="cart-item-info">
          <h5>${escapeHTML(item.service_name)}</h5>
          <small>${escapeHTML(item.property_type)} • ${escapeHTML(item.property_size)}</small>
          <div class="fw-bold text-accent">₹${Number(item.price).toLocaleString('en-IN')}</div>
        </div>
        <button type="button" class="cart-item-remove" title="Remove" onclick="removeStoreCartItem('${item.id}')">
          <i class="bi bi-trash3-fill"></i>
        </button>
      </div>
    `;
  });

  if (listEl) listEl.innerHTML = itemsHtml;

  const subtotal = cartData.subtotal || 0;
  const discount = appliedDiscount;
  const taxable = Math.max(0, subtotal - discount);
  const tax = Math.round(taxable * 0.18);
  const finalTotal = taxable + tax;

  if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toLocaleString('en-IN')}`;
  if (taxEl) taxEl.textContent = `₹${tax.toLocaleString('en-IN')}`;
  if (totalEl) totalEl.textContent = `₹${finalTotal.toLocaleString('en-IN')}`;
}

async function applyStoreCoupon() {
  const codeInput = document.getElementById('couponCodeInput');
  const code = codeInput?.value.trim().toUpperCase();
  const msgEl = document.getElementById('couponMessage');
  const discRow = document.getElementById('couponDiscountRow');
  const discDisplay = document.getElementById('cartDiscountDisplay');

  if (!code) {
    showToast('Please enter a coupon code.', 'error');
    return;
  }

  try {
    const res = await fetch('/api/coupon/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code })
    });

    const data = await res.json();
    if (data.success) {
      appliedDiscount = Number(data.discount_amount || 0);
      appliedCouponCode = data.code;
      if (msgEl) {
        msgEl.className = 'text-success d-block mt-1';
        msgEl.textContent = data.message;
      }
      if (discRow) discRow.style.display = 'flex';
      if (discDisplay) discDisplay.textContent = `- ₹${appliedDiscount.toLocaleString('en-IN')}`;
      
      showToast(data.message, 'success');
      fetchStoreCart();
    } else {
      if (msgEl) {
        msgEl.className = 'text-action d-block mt-1';
        msgEl.textContent = data.message;
      }
      showToast(data.message, 'error');
    }
  } catch (err) {
    console.error('Coupon error:', err);
    showToast('Could not apply coupon.', 'error');
  }
}

function proceedToCheckoutSection() {
  const checkoutCard = document.getElementById('checkoutFormCard');
  if (checkoutCard) {
    checkoutCard.style.display = 'block';
    checkoutCard.scrollIntoView({ behavior: 'smooth' });
    document.getElementById('orderCustName')?.focus();
  }
}

async function submitStoreOrder() {
  const name = document.getElementById('orderCustName')?.value.trim();
  const mobile = document.getElementById('orderCustMobile')?.value.trim();
  const address = document.getElementById('orderCustAddress')?.value.trim();
  const email = document.getElementById('orderCustEmail')?.value.trim();
  const area = document.getElementById('orderCustArea')?.value.trim();
  const date = document.getElementById('orderBookingDate')?.value;
  const time = document.getElementById('orderPreferredTime')?.value;
  const paymentMethod = document.querySelector('input[name="orderPaymentMethod"]:checked')?.value || 'cod';

  if (!name) {
    showToast('Please enter your full name.', 'error');
    document.getElementById('orderCustName')?.focus();
    return;
  }

  const cleanMobile = mobile.replace(/\D/g, '');
  if (cleanMobile.length < 10) {
    showToast('Please enter a valid 10-digit mobile number.', 'error');
    document.getElementById('orderCustMobile')?.focus();
    return;
  }

  if (!address) {
    showToast('Please enter your complete delivery/service address.', 'error');
    document.getElementById('orderCustAddress')?.focus();
    return;
  }

  const btn = document.getElementById('btnPlaceOrder');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span> Placing Order...`;
  }

  try {
    const res = await fetch('/api/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customer_name: name,
        mobile: cleanMobile,
        email: email,
        address: address,
        area: area,
        booking_date: date,
        preferred_time: time,
        payment_method: paymentMethod,
        discount_amount: appliedDiscount,
        coupon_code: appliedCouponCode
      })
    });

    const data = await res.json();
    if (data.success && data.order_id) {
      showToast('Order confirmed!', 'success');
      setTimeout(() => {
        window.location.href = `/order-confirm/${encodeURIComponent(data.order_id)}`;
      }, 500);
    } else {
      showToast(data.message || 'Could not place order.', 'error');
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i class="bi bi-bag-check-fill me-1"></i> Confirm & Place Order`;
      }
    }
  } catch (err) {
    console.error('Order submission error:', err);
    showToast('Server error while placing order. Please call 99721 76574.', 'error');
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-bag-check-fill me-1"></i> Confirm & Place Order`;
    }
  }
}
