const CACHE_NAME = 'slb-pest-control-v4';
const OFFLINE_URL = '/offline';

const PRECACHE_ASSETS = [
  '/',
  '/offline',
  '/static/css/bootstrap-icons.min.css',
  '/static/fonts/bootstrap-icons.woff2',
  '/static/css/main.css',
  '/static/js/main.js',
  '/static/images/logo.png',
  '/static/images/logo-transparent.png',
  '/static/images/favicon.png',
  '/static/images/google_review_badge.png',
  '/static/images/google_review_qr.png',
  '/static/images/google_qr_square.png',
  '/static/manifest.json',
  '/static/images/services/pure_cockroach-control.png',
  '/static/images/services/pure_termite-control.png',
  '/static/images/services/pure_bed-bug-treatment.png',
  '/static/images/services/pure_mosquito-control.png',
  '/static/images/services/pure_ant-control.png',
  '/static/images/services/pure_fly-control.png',
  '/static/images/services/pure_lizard-control.png',
  '/static/images/services/pure_spider-control.png',
  '/static/images/services/pure_rat-control.png',
  '/static/images/services/pure_rodent-control.png',
  '/static/images/services/pure_general-insect-control.png',
  '/static/images/services/pure_residential-pest-control.png',
  '/static/images/services/pure_commercial-pest-control.png',
  '/static/images/services/pure_office-pest-control.png',
  '/static/images/services/pure_apartment-pest-control.png',
  '/static/images/services/pure_restaurant-pest-control.png',
  '/static/images/services/pure_warehouse-pest-control.png',
  '/static/images/services/pure_preventive-pest-control.png'
];

// Install: precache offline page and critical assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('Pre-caching asset warning:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate: cleanup old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch: Network-first for HTML pages with offline fallback, Cache-first for static assets
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Admin routes & API should bypass cache completely
  if (url.pathname.startsWith('/admin') || url.pathname.startsWith('/api/')) {
    return;
  }

  // Handle navigation (HTML pages)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Cache successful page navigations
          if (response.status === 200) {
            const responseClone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return response;
        })
        .catch(async () => {
          const cached = await caches.match(event.request);
          if (cached) return cached;
          const offlineFallback = await caches.match(OFFLINE_URL);
          return offlineFallback || new Response('Offline - Please call SLB Pest Control at 99721 76574', {
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
          });
        })
    );
    return;
  }

  // Handle static assets (CSS, JS, images, fonts)
  if (
    url.pathname.startsWith('/static/') ||
    url.hostname.includes('fonts.googleapis.com') ||
    url.hostname.includes('fonts.gstatic.com') ||
    url.hostname.includes('cdn.jsdelivr.net')
  ) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          // Stale-while-revalidate in background
          fetch(event.request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkResponse));
            }
          }).catch(() => {});
          return cachedResponse;
        }

        return fetch(event.request).then((networkResponse) => {
          if (!networkResponse || networkResponse.status !== 200 || networkResponse.type === 'opaque') {
            return networkResponse;
          }
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseToCache));
          return networkResponse;
        });
      })
    );
  }
});
