// ==========================================================================
// SLB PEST CONTROL — MULTI-STEP BOOKING WIZARD LOGIC
// Synchronized with templates/booking.html & app.py
// ==========================================================================

const wizardState = {
  currentStep: 1,
  totalSteps: 5,
  service_id: null,
  service_name: '',
  property_type: 'House',
  property_size: '500-1000 sq.ft.',
  booking_date: '',
  preferred_time: 'Morning (8:00 AM - 12:00 PM)',
  customer_name: '',
  mobile: '',
  whatsapp: '',
  email: '',
  address: '',
  area: '',
  pincode: '',
  additional_requirements: '',
  photoFile: null
};

document.addEventListener('DOMContentLoaded', () => {
  initBookingWizard();
});

function initBookingWizard() {
  // Set default minimum date to tomorrow
  const dateInput = document.getElementById('wizardBookingDate');
  if (dateInput) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const yyyy = tomorrow.getFullYear();
    const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const dd = String(tomorrow.getDate()).padStart(2, '0');
    const defaultDate = `${yyyy}-${mm}-${dd}`;
    dateInput.min = defaultDate;
    dateInput.value = defaultDate;
    wizardState.booking_date = defaultDate;

    dateInput.addEventListener('change', (e) => {
      wizardState.booking_date = e.target.value;
    });
  }

  // Preselect already highlighted service
  const selectedServiceTile = document.querySelector('#serviceSelectionGrid .select-tile.selected');
  if (selectedServiceTile) {
    wizardState.service_id = selectedServiceTile.getAttribute('data-service-id');
    wizardState.service_name = selectedServiceTile.getAttribute('data-service-name');
  } else {
    // Default to first service tile if available
    const firstTile = document.querySelector('#serviceSelectionGrid .select-tile');
    if (firstTile) {
      firstTile.classList.add('selected');
      wizardState.service_id = firstTile.getAttribute('data-service-id');
      wizardState.service_name = firstTile.getAttribute('data-service-name');
    }
  }

  // Parse URL query parameters (e.g. ?service=2&area=Rajajinagar)
  const urlParams = new URLSearchParams(window.location.search);
  const areaParam = urlParams.get('area');
  if (areaParam) {
    const custAreaInput = document.getElementById('custArea');
    if (custAreaInput) {
      custAreaInput.value = areaParam;
      wizardState.area = areaParam;
    }
  }
  const serviceParam = urlParams.get('service');
  if (serviceParam) {
    const matchingTile = document.querySelector(`#serviceSelectionGrid .select-tile[data-service-id="${serviceParam}"]`);
    if (matchingTile) {
      document.querySelectorAll('#serviceSelectionGrid .select-tile').forEach(t => t.classList.remove('selected'));
      matchingTile.classList.add('selected');
      wizardState.service_id = serviceParam;
      wizardState.service_name = matchingTile.getAttribute('data-service-name');
    }
  }

  const propTypeParam = urlParams.get('prop_type');
  if (propTypeParam) {
    const typeTiles = document.querySelectorAll('#propertyTypeGrid .select-tile');
    typeTiles.forEach(tile => {
      if (tile.getAttribute('onclick') && tile.getAttribute('onclick').includes(`'${propTypeParam}'`)) {
        typeTiles.forEach(t => t.classList.remove('selected'));
        tile.classList.add('selected');
        wizardState.property_type = propTypeParam;
      }
    });
  }

  const propSizeParam = urlParams.get('prop_size');
  if (propSizeParam) {
    const sizeTiles = document.querySelectorAll('#propertySizeGrid .select-tile');
    sizeTiles.forEach(tile => {
      if (tile.getAttribute('onclick') && tile.getAttribute('onclick').includes(`'${propSizeParam}'`)) {
        sizeTiles.forEach(t => t.classList.remove('selected'));
        tile.classList.add('selected');
        wizardState.property_size = propSizeParam;
      }
    });
  }
}

function wizardSelectService(element, id, name) {
  document.querySelectorAll('#serviceSelectionGrid .select-tile').forEach(t => t.classList.remove('selected'));
  element.classList.add('selected');
  wizardState.service_id = id;
  wizardState.service_name = name;
}

function wizardSelectOption(field, value, element) {
  const grid = element.parentElement;
  if (grid) {
    grid.querySelectorAll('.select-tile').forEach(t => t.classList.remove('selected'));
  }
  element.classList.add('selected');
  wizardState[field] = value;
}

function wizardSelectTimeSlot(value, element) {
  document.querySelectorAll('.time-slot-tile').forEach(t => t.classList.remove('selected'));
  element.classList.add('selected');
  wizardState.preferred_time = value;
}

function wizardNextStep() {
  if (!validateStep(wizardState.currentStep)) {
    return;
  }

  if (wizardState.currentStep < wizardState.totalSteps) {
    wizardState.currentStep++;
    updateWizardUI();
  }
}

function wizardPrevStep() {
  if (wizardState.currentStep > 1) {
    wizardState.currentStep--;
    updateWizardUI();
  }
}

function updateWizardUI() {
  // Update Stepper Nodes
  for (let i = 1; i <= wizardState.totalSteps; i++) {
    const node = document.getElementById(`node${i}`);
    const panel = document.getElementById(`stepPanel${i}`);

    if (node) {
      node.classList.remove('active', 'completed');
      if (i === wizardState.currentStep) {
        node.classList.add('active');
      } else if (i < wizardState.currentStep) {
        node.classList.add('completed');
      }
    }

    if (panel) {
      if (i === wizardState.currentStep) {
        panel.classList.add('active');
      } else {
        panel.classList.remove('active');
      }
    }
  }

  // Populate Review step when reaching step 5
  if (wizardState.currentStep === 5) {
    populateReviewSummary();
  }

  window.scrollTo({ top: 150, behavior: 'smooth' });
}

function validateStep(step) {
  if (step === 1) {
    if (!wizardState.service_name) {
      showToast('Please select a pest control service to continue.', 'error');
      return false;
    }
    return true;
  }

  if (step === 2) {
    if (!wizardState.property_type || !wizardState.property_size) {
      showToast('Please select property type and approximate size.', 'error');
      return false;
    }
    return true;
  }

  if (step === 3) {
    const dateVal = document.getElementById('wizardBookingDate')?.value;
    if (!dateVal) {
      showToast('Please pick a booking appointment date.', 'error');
      return false;
    }
    wizardState.booking_date = dateVal;
    return true;
  }

  if (step === 4) {
    const name = document.getElementById('custName')?.value.trim();
    const mobile = document.getElementById('custMobile')?.value.trim();
    const address = document.getElementById('custAddress')?.value.trim();

    if (!name) {
      showToast('Please enter your full name.', 'error');
      document.getElementById('custName')?.focus();
      return false;
    }

    const cleanMobile = mobile.replace(/\D/g, '');
    if (cleanMobile.length < 10) {
      showToast('Please enter a valid 10-digit mobile number.', 'error');
      document.getElementById('custMobile')?.focus();
      return false;
    }

    if (!address) {
      showToast('Please enter your complete service address.', 'error');
      document.getElementById('custAddress')?.focus();
      return false;
    }

    wizardState.customer_name = name;
    wizardState.mobile = cleanMobile;
    wizardState.whatsapp = document.getElementById('custWhatsApp')?.value.trim() || cleanMobile;
    wizardState.email = document.getElementById('custEmail')?.value.trim();
    wizardState.address = address;
    wizardState.area = document.getElementById('custArea')?.value.trim();
    wizardState.pincode = document.getElementById('custPincode')?.value.trim();
    wizardState.additional_requirements = document.getElementById('custNotes')?.value.trim();
    return true;
  }

  return true;
}

function populateReviewSummary() {
  document.getElementById('revService').textContent = wizardState.service_name || 'N/A';
  document.getElementById('revProperty').textContent = `${wizardState.property_type} (${wizardState.property_size})`;
  document.getElementById('revDate').textContent = wizardState.booking_date || 'N/A';
  document.getElementById('revTime').textContent = wizardState.preferred_time || 'N/A';
  document.getElementById('revName').textContent = wizardState.customer_name || 'N/A';
  document.getElementById('revPhone').textContent = wizardState.mobile || 'N/A';
  
  let addrDisplay = wizardState.address;
  if (wizardState.area) addrDisplay += `, ${wizardState.area}`;
  if (wizardState.pincode) addrDisplay += ` - ${wizardState.pincode}`;
  document.getElementById('revAddress').textContent = addrDisplay;
}

function handleWizardPhoto(input) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    if (file.size > 10 * 1024 * 1024) {
      showToast('Photo file size must be less than 10MB.', 'error');
      input.value = '';
      return;
    }
    wizardState.photoFile = file;
    document.getElementById('photoPreviewName').textContent = `Selected: ${file.name}`;
    document.getElementById('photoPreviewContainer').style.display = 'flex';
  }
}

function clearWizardPhoto() {
  wizardState.photoFile = null;
  const input = document.getElementById('custPhotoInput');
  if (input) input.value = '';
  document.getElementById('photoPreviewContainer').style.display = 'none';
}

async function submitWizardBooking() {
  const submitBtn = document.getElementById('btnSubmitBooking');
  if (!submitBtn) return;

  const originalContent = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span> Confirming Booking...`;

  const formData = new FormData();
  formData.append('customer_name', wizardState.customer_name);
  formData.append('mobile', wizardState.mobile);
  formData.append('whatsapp', wizardState.whatsapp || wizardState.mobile);
  formData.append('email', wizardState.email);
  formData.append('address', wizardState.address);
  formData.append('area', wizardState.area);
  formData.append('pincode', wizardState.pincode);
  formData.append('service_id', wizardState.service_id || '');
  formData.append('service_name', wizardState.service_name);
  formData.append('property_type', wizardState.property_type);
  formData.append('property_size', wizardState.property_size);
  formData.append('booking_date', wizardState.booking_date);
  formData.append('preferred_time', wizardState.preferred_time);
  formData.append('additional_requirements', wizardState.additional_requirements);

  if (wizardState.photoFile) {
    formData.append('photo', wizardState.photoFile);
  }

  // Include CSRF Token
  const metaCsrf = document.querySelector('meta[name="csrf-token"]');
  if (metaCsrf) {
    formData.append('csrf_token', metaCsrf.getAttribute('content'));
  }

  try {
    const res = await fetch('/api/booking', {
      method: 'POST',
      body: formData
    });

    const data = await res.json();
    if (data.success && data.booking_id) {
      showToast('Booking successfully confirmed!', 'success');
      setTimeout(() => {
        window.location.href = `/booking-confirm/${encodeURIComponent(data.booking_id)}`;
      }, 600);
    } else {
      showToast(data.message || 'Booking submission failed. Please check your details.', 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalContent;
    }
  } catch (err) {
    console.error('Booking submission error:', err);
    showToast('Network or server error while submitting booking. Please try again or call 99721 76574.', 'error');
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalContent;
  }
}
