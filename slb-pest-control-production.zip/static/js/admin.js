// ==========================================================================
// SLB PEST CONTROL — WORLD-CLASS ENTERPRISE ADMIN PORTAL CLIENT SCRIPT
// Designed for rapid operational dispatch, live search & keyboard shortcuts
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  initAdminSidebar();
  initAdminCSRF();
  initBengaluruClock();
  initKeyboardShortcuts();
  initModalListeners();
});

// Mobile Sidebar Toggle
function initAdminSidebar() {
  const toggleBtn = document.getElementById('sidebarToggleBtn');
  const sidebar = document.getElementById('adminSidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });

    // Close sidebar on click outside on mobile
    document.addEventListener('click', (e) => {
      if (window.innerWidth < 992) {
        if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
          sidebar.classList.remove('open');
        }
      }
    });
  }
}

// Live Bengaluru Clock (IST)
function initBengaluruClock() {
  const clockEl = document.getElementById('adminLiveClock');
  if (!clockEl) return;

  function updateClock() {
    const now = new Date();
    // Format to Indian Standard Time (IST)
    const options = {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    try {
      const timeStr = new Intl.DateTimeFormat('en-IN', options).format(now);
      clockEl.textContent = `${timeStr} IST`;
    } catch (e) {
      clockEl.textContent = now.toLocaleTimeString() + ' IST';
    }
  }

  updateClock();
  setInterval(updateClock, 1000);
}

// Global Keyboard Shortcuts (Press / for search, Esc to close modals)
function initKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Esc key closes modals
    if (e.key === 'Escape') {
      closeQuickBookingModal();
      closeInspectionModal();
    }

    // Slash key focuses search
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      const searchInput = document.getElementById('globalAdminSearch') || 
                          document.getElementById('bookingSearchInput') ||
                          document.getElementById('orderSearchInput') ||
                          document.getElementById('pricingSearchInput');
      if (searchInput) {
        searchInput.focus();
        searchInput.select();
      }
    }
  });
}

// Universal Live Table Filter
function filterActiveAdminTable(query) {
  const q = (query || '').toLowerCase().trim();
  const tables = document.querySelectorAll('.admin-table');

  tables.forEach(table => {
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      // Skip placeholder empty rows
      if (row.cells.length <= 1) return;
      
      const text = row.textContent.toLowerCase();
      if (!q || text.includes(q)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
}

// Bookings Specific Search Filter
function searchBookingsTable(query) {
  filterActiveAdminTable(query);
}

// Quick Manual Booking Modal Handlers
function openQuickBookingModal() {
  const modal = document.getElementById('quickBookingModal');
  if (modal) {
    modal.style.display = 'flex';
    // Set default date to today
    const dateInput = document.getElementById('quickBookingDate');
    if (dateInput && !dateInput.value) {
      const today = new Date().toISOString().split('T')[0];
      dateInput.value = today;
    }
    // Focus first input
    const firstInput = modal.querySelector('input[name="customer_name"]');
    if (firstInput) setTimeout(() => firstInput.focus(), 100);
  }
}

function closeQuickBookingModal() {
  const modal = document.getElementById('quickBookingModal');
  if (modal) modal.style.display = 'none';
}

// Full Customer Inspection Card Modal Handlers
function viewInspectionModal(bookingId, custName, mobile, service, propType, propSize, bDate, bTime, address, area, pincode, notes) {
  const modal = document.getElementById('inspectionModal');
  if (!modal) return;

  // Populate data fields
  const titleEl = document.getElementById('modalBookingIdTitle');
  if (titleEl) titleEl.textContent = `Inspection Card &bull; ${bookingId}`;

  const cNameEl = document.getElementById('mCustName');
  if (cNameEl) cNameEl.textContent = custName || '-';

  const cMobileEl = document.getElementById('mCustMobile');
  if (cMobileEl) cMobileEl.textContent = mobile || '-';

  const cServiceEl = document.getElementById('mService');
  if (cServiceEl) cServiceEl.textContent = service || '-';

  const cPropEl = document.getElementById('mProperty');
  if (cPropEl) cPropEl.textContent = `${propType || 'Residential'} (${propSize || 'Standard'})`;

  const cScheduleEl = document.getElementById('mSchedule');
  if (cScheduleEl) cScheduleEl.textContent = `${bDate || 'Pending'} &bull; ${bTime || ''}`;

  const cAreaEl = document.getElementById('mArea');
  if (cAreaEl) cAreaEl.textContent = area ? `${area}, Bengaluru ${pincode || ''}` : 'Bengaluru';

  const cAddressEl = document.getElementById('mAddress');
  if (cAddressEl) cAddressEl.textContent = address || 'No address provided';

  const cNotesEl = document.getElementById('mNotes');
  const cNotesWrap = document.getElementById('mNotesWrap');
  if (cNotesEl && cNotesWrap) {
    if (notes && notes.trim()) {
      cNotesEl.textContent = notes;
      cNotesWrap.style.display = 'block';
    } else {
      cNotesWrap.style.display = 'none';
    }
  }

  // Configure 1-Click Call Button
  const callBtn = document.getElementById('mCallBtn');
  if (callBtn) {
    callBtn.href = `tel:${mobile}`;
  }

  // Configure 1-Click WhatsApp Button
  const waBtn = document.getElementById('mWhatsAppBtn');
  if (waBtn) {
    const cleanMobile = (mobile || '').replace(/\D/g, '');
    const cleanNumber = cleanMobile.startsWith('91') ? cleanMobile : `91${cleanMobile}`;
    const textMsg = encodeURIComponent(`Hello ${custName}, this is SLB Pest Control regarding your booking ${bookingId} for ${service} scheduled on ${bDate}. Our team is preparing for your service.`);
    waBtn.href = `https://wa.me/${cleanNumber}?text=${textMsg}`;
  }

  modal.style.display = 'flex';
}

function closeInspectionModal() {
  const modal = document.getElementById('inspectionModal');
  if (modal) modal.style.display = 'none';
}

// Modal Backdrop Click Dismiss
function initModalListeners() {
  document.querySelectorAll('.admin-modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.style.display = 'none';
      }
    });
  });
}

// CSRF Token Injection for Async Fetch
function initAdminCSRF() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  const token = meta ? meta.getAttribute('content') : '';

  if (token) {
    const originalFetch = window.fetch;
    window.fetch = function(url, options = {}) {
      options.headers = options.headers || {};
      const method = (options.method || 'GET').toUpperCase();
      if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
        if (options.headers instanceof Headers) {
          options.headers.set('X-CSRF-Token', token);
        } else {
          options.headers['X-CSRF-Token'] = token;
        }
      }
      return originalFetch(url, options);
    };
  }
}
